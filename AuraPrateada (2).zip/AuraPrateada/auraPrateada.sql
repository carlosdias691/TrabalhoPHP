drop database auraPrateada;
CREATE SCHEMA IF NOT EXISTS `auraPrateada` DEFAULT CHARACTER SET utf8;
USE `auraPrateada`;


CREATE TABLE `cadastro` (
  `id_usuario` INT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `senha` VARCHAR(255) NOT NULL,
  `telefone` VARCHAR(15) NOT NULL,
  PRIMARY KEY (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;


CREATE TABLE `produto` (
  `id_produto` INT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(100) DEFAULT NULL,
  `descricao` TEXT DEFAULT NULL,
  `preco` DECIMAL(10,2) DEFAULT NULL,
  `quantidade` INT(11) NOT NULL,  -- Quantidade disponível em estoque
  `imagem` VARCHAR(255) DEFAULT NULL,
  `categoria` VARCHAR(50) DEFAULT NULL,
  PRIMARY KEY (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;


CREATE TABLE `pedido` (
  `id_pedido` INT(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` INT(11) NOT NULL,
  `id_produto` INT(11) NOT NULL,
  `quantidade` INT(11) NOT NULL,
  `preco_unitario` DECIMAL(10,2) NOT NULL,
  `estatus` VARCHAR(50) DEFAULT 'pendente',  -- Status do pedido
  `total` DECIMAL(10,2) NOT NULL,  -- Preço total do pedido
  PRIMARY KEY (`id_pedido`),
  FOREIGN KEY (`id_usuario`) REFERENCES `cadastro` (`id_usuario`),
  FOREIGN KEY (`id_produto`) REFERENCES `produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;


CREATE TABLE `carrinho` (
  `id_carrinho` INT(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` INT(11) NOT NULL,
  `id_produto` INT(11) NOT NULL,
  `quantidade` INT(11) DEFAULT NULL,
  PRIMARY KEY (`id_carrinho`),
  FOREIGN KEY (`id_usuario`) REFERENCES `cadastro` (`id_usuario`),
  FOREIGN KEY (`id_produto`) REFERENCES `produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;


DELIMITER $$
CREATE TRIGGER `Atualizacao_de_estoque` 
AFTER INSERT ON `pedido`
FOR EACH ROW 
BEGIN
    
    UPDATE `produto`
    SET `quantidade` = `quantidade` - NEW.`quantidade`
    WHERE `id_produto` = NEW.`id_produto`;
END
$$
DELIMITER ;

SELECT * FROM `pedido`;

SELECT * FROM `produto`;

SELECT 
    pr.nome AS produto_nome,
    SUM(p.quantidade) AS quantidade_vendida,
    pr.preco AS preco_unitario,
    SUM(p.quantidade * pr.preco) AS total_vendas
FROM 
    pedido p
INNER JOIN 
    produto pr ON p.id_produto = pr.id_produto
GROUP BY 
    pr.id_produto, pr.nome, pr.preco;

