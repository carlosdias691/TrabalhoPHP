<?php
// Conectar ao banco de dados
include 'conexao.php';  // Supondo que a conexão com o banco está em um arquivo separado

// Define a query SQL com INNER JOIN
$sql = "SELECT 
            p.id_pedido,
            u.nome AS usuario_nome,
            u.email AS usuario_email,
            pr.nome AS produto_nome,
            pr.preco AS preco_unitario,
            p.quantidade AS quantidade,
            p.total AS total_pedido,
            p.estatus AS status_pedido
        FROM 
            pedido p
        INNER JOIN 
            cadastro u ON p.id_usuario = u.id_usuario
        INNER JOIN 
            produto pr ON p.id_produto = pr.id_produto";

// Executa a query
$result = $conn->query($sql);

// Inicia a estrutura HTML
echo "<table border='1'>
        <tr>
            <th>ID Pedido</th>
            <th>Usuário</th>
            <th>Email</th>
            <th>Produto</th>
            <th>Preço Unitário</th>
            <th>Quantidade</th>
            <th>Total</th>
            <th>Status</th>
        </tr>";

// Verifica se há resultados
if ($result->num_rows > 0) {
    // Exibe os resultados
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row['id_pedido'] . "</td>
                <td>" . $row['usuario_nome'] . "</td>
                <td>" . $row['usuario_email'] . "</td>
                <td>" . $row['produto_nome'] . "</td>
                <td>" . $row['preco_unitario'] . "</td>
                <td>" . $row['quantidade'] . "</td>
                <td>" . $row['total_pedido'] . "</td>
                <td>" . $row['status_pedido'] . "</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "Nenhum pedido encontrado.";
}

// Fecha a conexão
$conn->close();
?>
