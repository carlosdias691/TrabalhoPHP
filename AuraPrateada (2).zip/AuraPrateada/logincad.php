    <!doctype html>
    <html lang="pt-BR">
    <?php
    include "Modelo/DAO/Conexao.php";
    include "Controle/ControleLogin.php"
    ?>
    <head>
        <title>Aura </title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.9/css/unicons.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="Visao/CSS/style.css">
        <link rel="shortcut icon" href="Visao/imagem/logo.ico" type="image/x-icon">
    </head>
    <body>
        <div class="img">
            <div class="section">
                <div class="container">
                    <div class="row full-height justify-content-center">
                        <div class="col-12 text-center align-self-center py-5">
                            <div class="section pb-5 pt-5 pt-sm-2 text-center">
                                <h6 class="mb-0 pb-3"><span>Entrar </span><span>Cadrastar</span></h6>
                                <input class="checkbox" type="checkbox" id="reg-log" name="reg-log" />
                                <label for="reg-log"></label>
                                <div class="card-3d-wrap mx-auto">
                                    <div class="card-3d-wrapper">
                                        <div class="card-front">
                                            <div class="center-wrap">
                                                <div class="section text-center">
                                                    <h4 class="mb-4 pb-3">Conecte-se</h4>
                                                    <form action="logincad.php" method="POST">
                                                        <input type="hidden" name="acao" value="login">
                                                        <div class="form-group">
                                                            <input type="email" name="email" class="form-style" placeholder="Email" required>
                                                            <i class="input-icon uil uil-at"></i>
                                                        </div>
                                                        <div class="form-group mt-2">
                                                            <input type="password" name="senha" class="form-style" placeholder="Senha" required>
                                                            <i class="input-icon uil uil-lock-alt"></i>
                                                        </div>
                                                        <button type="submit" class="btn mt-4">Entrar</button>
                                                        <p class="mb-0 mt-4 text-center"><a href="redefiniçao.php" class="link">Esqueceu sua senha?</a></p>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-back">
                                            <div class="center-wrap">
                                                <div class="section text-center">
                                                    <h4 class="mb-3 pb-3">Criar conta</h4>
                                                    <form action="logincad.php" method="POST">
                                                        <input type="hidden" name="acao" value="cadastro">
                                                        <div class="form-group">
                                                            <input type="text" name="nome" class="form-style" placeholder="Nome completo" required>
                                                            <i class="input-icon uil uil-user"></i>
                                                        </div>
                                                        <div class="form-group mt-2">
                                                            <input type="tel" name="telefone" class="form-style" placeholder="Número">
                                                            <i class="input-icon uil uil-phone"></i>
                                                        </div>
                                                        <div class="form-group mt-2">
                                                            <input type="email" name="email" class="form-style" placeholder="Email" required>
                                                            <i class="input-icon uil uil-at"></i>
                                                        </div>
                                                        <div class="form-group mt-2">
                                                            <input type="password" name="senha" class="form-style" placeholder="Senha" required>
                                                            <i class="input-icon uil uil-lock-alt"></i>
                                                        </div>
                                                        <button type="submit" class="btn mt-4">Registrar</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>