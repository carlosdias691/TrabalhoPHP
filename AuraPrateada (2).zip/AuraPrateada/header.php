<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<nav>
    <ul>
        <li><a href="/Visao/css/index.php">Home</a></li>
        <li><a href="/Visao/CSS/Braceletes.php">Braceletes</a></li>
        <li><a href="/Visao/CSS/Aneis.php">Anéis</a></li>
        <li><a href="/Visao/CSS/Colares.php">Colares</a></li>
        <li><a href="/Visao/CSS/Brincos.php">Brincos</a></li>
    </ul>
</nav> 
</body>
</html>